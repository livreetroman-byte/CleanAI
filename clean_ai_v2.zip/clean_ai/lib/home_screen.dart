import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'scan_screen.dart';
import 'scanner.dart';
import 'widgets.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    await Store.load();
    if (mounted) setState(() {});
  }

  Future<void> _open([Cat? only]) async {
    await Navigator.of(context).push(smoothRoute(ScanScreen(only: only)));
    await Store.refreshDisk();
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    final used = (Store.totalGB - Store.freeGB).clamp(0, double.infinity);
    final pct = Store.totalGB > 0 ? (used / Store.totalGB * 100).round() : 0;
    final display = GoogleFonts.sora(fontWeight: FontWeight.w700, color: p.ink);

    return Scaffold(
      backgroundColor: p.bg,
      body: GlowBackground(
        child: SafeArea(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
            children: [
              Row(children: [
                Text('Clean AI', style: display.copyWith(fontSize: 28, letterSpacing: -.5)),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(99),
                    color: Color.alphaBlend(p.mint.withOpacity(.3), p.surface),
                    boxShadow: [BoxShadow(color: p.mint.withOpacity(.5), blurRadius: 18)],
                  ),
                  child: Row(children: [
                    Icon(Icons.workspace_premium_rounded, size: 16, color: p.green),
                    const SizedBox(width: 6),
                    Text('PRO', style: TextStyle(color: p.ink, fontWeight: FontWeight.w800, fontSize: 13, letterSpacing: .6)),
                  ]),
                ),
              ]),
              const SizedBox(height: 16),
              Row(children: [
                _Stat(icon: Icons.sd_storage_rounded, color: p.blue, value: '${Store.freeGB.toStringAsFixed(1)} Go', label: 'Libre'),
                const SizedBox(width: 10),
                _Stat(icon: Icons.cleaning_services_rounded, color: p.violet, value: fmtBytes(Store.cleanedBytes), label: 'Nettoyé'),
                const SizedBox(width: 10),
                _Stat(icon: Icons.pie_chart_rounded, color: p.green, value: '$pct %', label: 'Utilisé'),
              ]),
              const SizedBox(height: 18),
              _Hero(used: used.toDouble(), total: Store.totalGB, pct: pct, onTap: () => _open()),
              const SizedBox(height: 22),
              Text('Actions rapides', style: display.copyWith(fontSize: 18)),
              const SizedBox(height: 12),
              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 1.3,
                children: [
                  for (final c in [Cat.junk, Cat.dup, Cat.large, Cat.cache])
                    _Tile(cat: c, bytes: Store.lastFound[c], onTap: () => _open(c)),
                ],
              ),
              const SizedBox(height: 18),
              _Boost(onTap: () => _open()),
            ],
          ),
        ),
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String value, label;
  const _Stat({required this.icon, required this.color, required this.value, required this.label});

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: p.surface,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: p.line),
        ),
        child: Row(children: [
          Icon(icon, size: 22, color: color),
          const SizedBox(width: 8),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              FittedBox(
                fit: BoxFit.scaleDown,
                child: Text(value, style: GoogleFonts.sora(fontWeight: FontWeight.w700, fontSize: 14, color: p.ink)),
              ),
              Text(label, style: TextStyle(fontSize: 11.5, color: p.ink2)),
            ]),
          ),
        ]),
      ),
    );
  }
}

class _Hero extends StatelessWidget {
  final double used, total;
  final int pct;
  final VoidCallback onTap;
  const _Hero({required this.used, required this.total, required this.pct, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 20, 16, 16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        gradient: LinearGradient(colors: [p.heroA, p.heroB], begin: Alignment.topLeft, end: Alignment.bottomRight),
        boxShadow: [BoxShadow(color: p.blue.withOpacity(.35), blurRadius: 40, offset: const Offset(0, 18), spreadRadius: -12)],
      ),
      child: Row(children: [
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Stockage utilisé', style: TextStyle(color: p.ink.withOpacity(.75), fontSize: 14)),
            const SizedBox(height: 4),
            Text('${used.toStringAsFixed(1)} Go',
                style: GoogleFonts.sora(fontWeight: FontWeight.w700, fontSize: 36, color: p.ink, letterSpacing: -1)),
            const SizedBox(height: 10),
            ClipRRect(
              borderRadius: BorderRadius.circular(99),
              child: TweenAnimationBuilder<double>(
                tween: Tween<double>(end: total > 0 ? (used / total).clamp(0.0, 1.0).toDouble() : 0.0),
                duration: const Duration(milliseconds: 1100),
                curve: Curves.easeOutCubic,
                builder: (_, v, __) => LinearProgressIndicator(
                  value: v,
                  minHeight: 8,
                  backgroundColor: p.ink.withOpacity(.14),
                  valueColor: AlwaysStoppedAnimation(p.blue),
                ),
              ),
            ),
            const SizedBox(height: 8),
            Text('sur ${total.toStringAsFixed(0)} Go · $pct % utilisé', style: TextStyle(color: p.ink.withOpacity(.75), fontSize: 12.5)),
          ]),
        ),
        const SizedBox(width: 10),
        Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            width: 84,
            height: 84,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white.withOpacity(.55),
              boxShadow: [BoxShadow(color: p.blue.withOpacity(.45), blurRadius: 30)],
            ),
            child: Icon(Icons.delete_sweep_rounded, size: 44, color: p.blue),
          ),
          const SizedBox(height: 10),
          Material(
            color: p.surface,
            shape: const CircleBorder(),
            elevation: 4,
            shadowColor: p.blue,
            child: InkWell(
              customBorder: const CircleBorder(),
              onTap: onTap,
              child: SizedBox(width: 38, height: 38, child: Icon(Icons.arrow_forward_rounded, size: 18, color: p.ink)),
            ),
          ),
        ]),
      ]),
    );
  }
}

class _Tile extends StatelessWidget {
  final Cat cat;
  final int? bytes;
  final VoidCallback onTap;
  const _Tile({required this.cat, required this.bytes, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    final c = p.forCat(cat);
    return Material(
      color: Colors.transparent,
      child: Ink(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: c.withOpacity(.18)),
          gradient: LinearGradient(
            colors: [Color.alphaBlend(c.withOpacity(.20), p.surface), Color.alphaBlend(c.withOpacity(.06), p.surface)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: InkWell(
          borderRadius: BorderRadius.circular(22),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Container(
                width: 30,
                height: 30,
                decoration: BoxDecoration(color: Color.alphaBlend(c.withOpacity(.28), p.surface), borderRadius: BorderRadius.circular(10)),
                child: Icon(cat.icon, size: 17, color: c),
              ),
              const Spacer(),
              Text(cat.label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 13, color: p.ink2, fontWeight: FontWeight.w600)),
              const SizedBox(height: 2),
              Row(children: [
                Expanded(
                  child: Text(
                    bytes == null ? 'Analyser' : (bytes == 0 ? 'Rien à nettoyer' : fmtBytes(bytes!)),
                    style: GoogleFonts.sora(fontWeight: FontWeight.w700, fontSize: 15, color: p.ink),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                Icon(Icons.arrow_forward_rounded, size: 15, color: p.ink),
              ]),
            ]),
          ),
        ),
      ),
    );
  }
}

class _Boost extends StatelessWidget {
  final VoidCallback onTap;
  const _Boost({required this.onTap});

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    return Container(
      padding: const EdgeInsets.fromLTRB(14, 12, 12, 12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: p.line),
        gradient: LinearGradient(colors: [Color.alphaBlend(p.blue.withOpacity(.14), p.surface), p.surface]),
      ),
      child: Row(children: [
        Icon(Icons.bolt_rounded, size: 30, color: p.blue, shadows: [Shadow(color: p.blue, blurRadius: 14)]),
        const SizedBox(width: 12),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Booster mon téléphone', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15, color: p.ink)),
            Text('Analyse complète du stockage', style: TextStyle(fontSize: 12, color: p.ink2)),
          ]),
        ),
        SizedBox(width: 112, child: GradientButton(label: 'Optimiser', onTap: onTap)),
      ]),
    );
  }
}
