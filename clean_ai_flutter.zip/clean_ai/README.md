# Clean AI (Flutter, Android)

Application de nettoyage de stockage avec **analyse et suppression réelles** des fichiers, au design de la maquette Clean AI (clair et sombre).

## Ce que fait l'application

| Fonction | Comportement réel |
|---|---|
| Stockage utilisé / libre | Lu sur l'appareil (`disk_space_plus`) |
| Fichiers inutiles | `.tmp`, `.log`, `.bak`, `.old`, `.chk`, miniatures `.thumbnails`, APK dans Téléchargements |
| Doublons | Même taille puis même empreinte MD5 (on garde un exemplaire) |
| Gros fichiers | Fichiers de plus de 100 Mo |
| Cache temporaire | Cache de **Clean AI** uniquement |
| Nettoyer | Supprime vraiment les fichiers cochés (définitif, avec confirmation pour doublons et gros fichiers) |

## Limites à connaître

- Android ne permet pas à une application de vider le cache **des autres applications** sans permission système spéciale. Le cache nettoyé ici est celui de Clean AI.
- L'accès à tous les fichiers (`MANAGE_EXTERNAL_STORAGE`) est très encadré par Google Play. L'installation directe de l'APK fonctionne, mais une publication sur le Play Store demande une justification.
- iPhone n'est pas pris en charge : iOS interdit ce type d'accès.
- Le code n'a pas pu être compilé dans l'environnement où il a été écrit (Flutter absent). Il faut le lancer une fois et corriger les éventuelles erreurs de version de paquets.

## Installation

1. Installer Flutter : https://docs.flutter.dev/get-started/install
2. Créer le squelette Android, puis copier ces fichiers dessus :
   ```bash
   flutter create clean_ai
   cd clean_ai
   # remplacer pubspec.yaml et le dossier lib/ par ceux de ce projet
   flutter pub get
   ```
3. Dans `android/app/src/main/AndroidManifest.xml`, ajouter avant `<application>` :
   ```xml
   <uses-permission android:name="android.permission.INTERNET"/>
   <uses-permission android:name="android.permission.MANAGE_EXTERNAL_STORAGE"/>
   <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32"/>
   <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="32"/>
   ```
   (`INTERNET` sert à télécharger les polices Google au premier lancement.)
4. Brancher un téléphone Android (mode développeur activé) et lancer :
   ```bash
   flutter run
   ```
5. Pour obtenir un fichier APK à installer :
   ```bash
   flutter build apk --release
   ```
   Le fichier est dans `build/app/outputs/flutter-apk/app-release.apk`.

## Si une erreur apparaît

- `disk_space_plus` : si `DiskSpacePlus.getFreeDiskSpace` ne compile pas, ouvrir la page du paquet sur pub.dev et adapter l'appel dans `lib/scanner.dart` (fonction `Store.refreshDisk`).
- Première analyse lente : normal sur un téléphone avec beaucoup de fichiers, le calcul des doublons lit les fichiers.

## Structure

```
lib/main.dart          thème clair/sombre
lib/scanner.dart       analyse, suppression, état partagé
lib/widgets.dart       palette, boutons, anneau de progression
lib/home_screen.dart   accueil
lib/scan_screen.dart   nettoyage intelligent
lib/result_screen.dart résultat
```
