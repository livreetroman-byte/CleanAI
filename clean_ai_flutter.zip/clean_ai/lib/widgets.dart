import 'dart:math' as math;

import 'package:flutter/material.dart';

import 'scanner.dart';

/// Palette claire / sombre issue de la maquette Clean AI.
class Pal {
  final Color bg, surface, surface2, ink, ink2, line;
  final Color blue, green, violet, amber, mint, heroA, heroB;
  const Pal({
    required this.bg, required this.surface, required this.surface2,
    required this.ink, required this.ink2, required this.line,
    required this.blue, required this.green, required this.violet,
    required this.amber, required this.mint,
    required this.heroA, required this.heroB,
  });

  static const light = Pal(
    bg: Color(0xFFE7F0FF), surface: Color(0xFFFFFFFF), surface2: Color(0xFFF2F6FF),
    ink: Color(0xFF0F1B3D), ink2: Color(0xFF55658A), line: Color(0x1A1E3C82),
    blue: Color(0xFF3B82F6), green: Color(0xFF16A34A), violet: Color(0xFF7C6CF0),
    amber: Color(0xFFE08A0B), mint: Color(0xFF3FD3AA),
    heroA: Color(0xFFA8D1FF), heroB: Color(0xFFB4F1DB),
  );
  static const dark = Pal(
    bg: Color(0xFF060B1C), surface: Color(0xFF101A38), surface2: Color(0xFF16224A),
    ink: Color(0xFFEAF0FF), ink2: Color(0xFF9AA9CC), line: Color(0x14FFFFFF),
    blue: Color(0xFF6AA5FF), green: Color(0xFF34D399), violet: Color(0xFFA99CFF),
    amber: Color(0xFFFBBF24), mint: Color(0xFF4FE0B8),
    heroA: Color(0xFF1E3A8A), heroB: Color(0xFF0F5F5A),
  );

  static Pal of(BuildContext c) =>
      Theme.of(c).brightness == Brightness.dark ? dark : light;

  Color forCat(Cat c) => switch (c) {
        Cat.junk => blue,
        Cat.cache => amber,
        Cat.dup => green,
        Cat.large => violet,
      };
}

extension CatX on Cat {
  String get label => switch (this) {
        Cat.junk => 'Fichiers inutiles',
        Cat.cache => 'Cache temporaire',
        Cat.dup => 'Doublons',
        Cat.large => 'Gros fichiers',
      };
  IconData get icon => switch (this) {
        Cat.junk => Icons.folder_rounded,
        Cat.cache => Icons.grid_view_rounded,
        Cat.dup => Icons.copy_rounded,
        Cat.large => Icons.image_rounded,
      };
}

String fmtBytes(num b) {
  if (b >= 1 << 30) return '${(b / (1 << 30)).toStringAsFixed(1)} Go';
  if (b >= 1 << 20) return '${(b / (1 << 20)).round()} Mo';
  if (b >= 1024) return '${(b / 1024).round()} Ko';
  return '${b.round()} o';
}

Route<T> smoothRoute<T>(Widget page) => PageRouteBuilder<T>(
      transitionDuration: const Duration(milliseconds: 350),
      pageBuilder: (_, __, ___) => page,
      transitionsBuilder: (_, a, __, child) {
        final curve = CurvedAnimation(parent: a, curve: Curves.easeOutCubic);
        return FadeTransition(
          opacity: curve,
          child: SlideTransition(
            position: Tween(begin: const Offset(0, .04), end: Offset.zero).animate(curve),
            child: child,
          ),
        );
      },
    );

/// Fond avec deux halos lumineux.
class GlowBackground extends StatelessWidget {
  final Widget child;
  const GlowBackground({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    final dark = Theme.of(context).brightness == Brightness.dark;
    final a = dark ? .35 : .55;
    Widget halo(Color c, double size) => Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: RadialGradient(colors: [c.withOpacity(a), c.withOpacity(0)]),
          ),
        );
    return Stack(children: [
      Positioned.fill(child: ColoredBox(color: p.bg)),
      Positioned(top: -140, left: -120, child: halo(dark ? const Color(0xFF1D4ED8) : const Color(0xFF8EBEFF), 460)),
      Positioned(bottom: -160, right: -140, child: halo(dark ? const Color(0xFF0F766E) : const Color(0xFF8DF0CF), 460)),
      Positioned.fill(child: child),
    ]);
  }
}

class GradientButton extends StatelessWidget {
  final String label;
  final VoidCallback? onTap;
  final bool busy;
  const GradientButton({super.key, required this.label, this.onTap, this.busy = false});

  @override
  Widget build(BuildContext context) {
    final enabled = onTap != null && !busy;
    return Opacity(
      opacity: onTap == null ? .5 : 1,
      child: Material(
        color: Colors.transparent,
        child: Ink(
          height: 54,
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFF3B82F6), Color(0xFF1D4ED8)]),
            borderRadius: BorderRadius.circular(99),
            boxShadow: [BoxShadow(color: const Color(0xFF3B82F6).withOpacity(.4), blurRadius: 24, offset: const Offset(0, 10))],
          ),
          child: InkWell(
            borderRadius: BorderRadius.circular(99),
            onTap: enabled ? onTap : null,
            child: Center(
              child: busy
                  ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white))
                  : Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 16)),
            ),
          ),
        ),
      ),
    );
  }
}

class SoftButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const SoftButton({super.key, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    return Material(
      color: Colors.transparent,
      child: Ink(
        height: 50,
        decoration: BoxDecoration(
          color: Color.alphaBlend(p.blue.withOpacity(.12), p.surface),
          borderRadius: BorderRadius.circular(99),
          border: Border.all(color: p.line),
        ),
        child: InkWell(
          borderRadius: BorderRadius.circular(99),
          onTap: onTap,
          child: Center(child: Text(label, style: TextStyle(color: p.blue, fontWeight: FontWeight.w700, fontSize: 15))),
        ),
      ),
    );
  }
}

class RoundIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const RoundIconButton({super.key, required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    return Material(
      color: p.surface,
      shape: CircleBorder(side: BorderSide(color: p.line)),
      elevation: 2,
      shadowColor: p.blue.withOpacity(.3),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: SizedBox(width: 42, height: 42, child: Icon(icon, size: 20, color: p.ink)),
      ),
    );
  }
}

/// Anneau de progression avec halo et pastille.
class RingPainter extends CustomPainter {
  final double p;
  final Color track;
  RingPainter(this.p, this.track);

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width / 2 - 14;
    final rect = Rect.fromCircle(center: c, radius: r);
    canvas.drawCircle(c, r, Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 14
      ..color = track);
    if (p <= 0) return;
    const grad = SweepGradient(
      colors: [Color(0xFF7DD3FC), Color(0xFF3B82F6)],
      transform: GradientRotation(-math.pi / 2),
    );
    final sweep = 2 * math.pi * p;
    canvas.drawArc(rect, -math.pi / 2, sweep, false, Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 14
      ..strokeCap = StrokeCap.round
      ..color = const Color(0xFF3B82F6).withOpacity(.55)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10));
    canvas.drawArc(rect, -math.pi / 2, sweep, false, Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 14
      ..strokeCap = StrokeCap.round
      ..shader = grad.createShader(rect));
    final a = -math.pi / 2 + sweep;
    final k = Offset(c.dx + r * math.cos(a), c.dy + r * math.sin(a));
    canvas.drawCircle(k, 7, Paint()..color = Colors.white);
    canvas.drawCircle(k, 7, Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3
      ..color = const Color(0xFF3B82F6));
  }

  @override
  bool shouldRepaint(RingPainter old) => old.p != p || old.track != track;
}
