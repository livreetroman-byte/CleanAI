import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'scanner.dart';
import 'widgets.dart';

class ResultScreen extends StatefulWidget {
  final int freed;
  final Map<Cat, int> details;
  const ResultScreen({super.key, required this.freed, required this.details});
  @override
  State<ResultScreen> createState() => _ResultScreenState();
}

class _ResultScreenState extends State<ResultScreen> {
  bool showDetails = false;

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    final display = GoogleFonts.sora(fontWeight: FontWeight.w700, color: p.ink);
    final nothing = widget.freed == 0;

    return Scaffold(
      backgroundColor: p.bg,
      body: GlowBackground(
        child: SafeArea(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
            children: [
              Row(children: [
                RoundIconButton(icon: Icons.chevron_left_rounded, onTap: _home),
                Expanded(child: Center(child: Text('Résultat', style: display.copyWith(fontSize: 17)))),
                RoundIconButton(icon: Icons.home_rounded, onTap: _home),
              ]),
              const SizedBox(height: 28),
              Center(
                child: TweenAnimationBuilder<double>(
                  tween: Tween(begin: 0, end: 1),
                  duration: const Duration(milliseconds: 800),
                  curve: Curves.elasticOut,
                  builder: (_, v, __) => Transform.scale(
                    scale: v,
                    child: Container(
                      width: 96,
                      height: 96,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: const LinearGradient(colors: [Color(0xFF5EE6A8), Color(0xFF16A34A)], begin: Alignment.topLeft, end: Alignment.bottomRight),
                        boxShadow: [
                          BoxShadow(color: p.green.withOpacity(.55), blurRadius: 44, spreadRadius: 8),
                          BoxShadow(color: p.green.withOpacity(.3), blurRadius: 90, spreadRadius: 24),
                        ],
                      ),
                      child: const Icon(Icons.check_rounded, size: 54, color: Colors.white),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 32),
              Center(child: Text(nothing ? 'Rien à nettoyer' : 'Nettoyage réussi !', style: display.copyWith(fontSize: 23, letterSpacing: -.4))),
              const SizedBox(height: 6),
              Center(
                child: TweenAnimationBuilder<double>(
                  tween: Tween(begin: 0, end: widget.freed.toDouble()),
                  duration: const Duration(milliseconds: 1000),
                  curve: Curves.easeOutCubic,
                  builder: (_, v, __) => Text('${fmtBytes(v)} d’espace libérés', style: TextStyle(color: p.ink2, fontSize: 14)),
                ),
              ),
              const SizedBox(height: 22),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: p.surface,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: p.line),
                ),
                child: Row(children: [
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(color: Color.alphaBlend(p.blue.withOpacity(.2), p.surface), borderRadius: BorderRadius.circular(16)),
                    child: Icon(Icons.storage_rounded, color: p.blue),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('Espace libéré', style: TextStyle(color: p.ink2, fontSize: 13)),
                      TweenAnimationBuilder<double>(
                        tween: Tween(begin: 0, end: widget.freed.toDouble()),
                        duration: const Duration(milliseconds: 1000),
                        curve: Curves.easeOutCubic,
                        builder: (_, v, __) => Text(fmtBytes(v), style: display.copyWith(fontSize: 26, letterSpacing: -.5)),
                      ),
                    ]),
                  ),
                  Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                    Text('Total nettoyé', style: TextStyle(color: p.ink2, fontSize: 12)),
                    Text(fmtBytes(Store.cleanedBytes), style: TextStyle(color: p.green, fontWeight: FontWeight.w700, fontSize: 15)),
                  ]),
                ]),
              ),
              const SizedBox(height: 22),
              GradientButton(label: 'Terminé', onTap: _home),
              const SizedBox(height: 10),
              SoftButton(
                label: showDetails ? 'Masquer les détails' : 'Voir les détails',
                onTap: () => setState(() => showDetails = !showDetails),
              ),
              AnimatedSize(
                duration: const Duration(milliseconds: 250),
                curve: Curves.easeOutCubic,
                child: showDetails
                    ? Container(
                        margin: const EdgeInsets.only(top: 12),
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                        decoration: BoxDecoration(
                          color: p.surface,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: p.line),
                        ),
                        child: Column(children: [
                          for (final e in widget.details.entries)
                            Padding(
                              padding: const EdgeInsets.symmetric(vertical: 10),
                              child: Row(children: [
                                Icon(e.key.icon, size: 18, color: p.forCat(e.key)),
                                const SizedBox(width: 10),
                                Expanded(child: Text(e.key.label, style: TextStyle(color: p.ink))),
                                Text(fmtBytes(e.value), style: TextStyle(color: p.ink, fontWeight: FontWeight.w700)),
                              ]),
                            ),
                          if (widget.details.isEmpty)
                            Padding(padding: const EdgeInsets.all(12), child: Text('Aucune catégorie sélectionnée', style: TextStyle(color: p.ink2))),
                        ]),
                      )
                    : const SizedBox(width: double.infinity),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _home() => Navigator.of(context).popUntil((r) => r.isFirst);
}
