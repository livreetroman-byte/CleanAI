import 'dart:io';
import 'dart:math' as math;

import 'package:crypto/crypto.dart';
import 'package:disk_space_plus/disk_space_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

enum Cat { junk, cache, dup, large }

class Found {
  final List<File> files = [];
  int bytes = 0;
}

typedef ProgressCb = void Function(double progress, String path);

class _F {
  final String path;
  final int size;
  _F(this.path, this.size);
}

/// Analyse et suppression réelles des fichiers (Android).
class Scanner {
  static const root = '/storage/emulated/0';
  static const junkExt = {'.tmp', '.temp', '.log', '.bak', '.old', '.chk', '.thumbdata'};
  static const largeMin = 100 * 1024 * 1024; // 100 Mo
  static const dupMin = 50 * 1024; // 50 Ko

  bool cancelled = false;

  /// Demande l'accès aux fichiers. Sur Android 11+, ouvre l'écran système
  /// « Accès à tous les fichiers ».
  static Future<bool> ensureAccess() async {
    if (!Platform.isAndroid) return false;
    if (await Permission.manageExternalStorage.isGranted) return true;
    final all = await Permission.manageExternalStorage.request();
    if (all.isGranted) return true;
    final legacy = await Permission.storage.request();
    if (legacy.isGranted) return true;
    if (all.isPermanentlyDenied && legacy.isPermanentlyDenied) {
      await openAppSettings();
    }
    return false;
  }

  Future<Map<Cat, Found>> scan(ProgressCb onProgress) async {
    final res = {for (final c in Cat.values) c: Found()};

    // 1. Cache temporaire de cette application
    onProgress(0.02, 'Cache temporaire');
    final cacheDirs = <Directory>[];
    try {
      cacheDirs.add(await getTemporaryDirectory());
    } catch (_) {}
    try {
      final ext = await getExternalCacheDirectories();
      if (ext != null) cacheDirs.addAll(ext);
    } catch (_) {}
    for (final d in cacheDirs) {
      try {
        await for (final e in d.list(recursive: true, followLinks: false)) {
          if (e is File) {
            res[Cat.cache]!.files.add(e);
            res[Cat.cache]!.bytes += _len(e);
          }
        }
      } catch (_) {}
    }

    // 2. Parcours du stockage interne (hors /Android)
    final bySize = <int, List<_F>>{};
    final stack = <Directory>[Directory(root)];
    var n = 0;
    while (stack.isNotEmpty && !cancelled) {
      final dir = stack.removeLast();
      try {
        await for (final e in dir.list(followLinks: false)) {
          if (e is Directory) {
            final name = e.path.split('/').last;
            if (dir.path == root && name == 'Android') continue;
            stack.add(e);
          } else if (e is File) {
            n++;
            final size = _len(e);
            final path = e.path;
            final lower = path.toLowerCase();
            final dot = lower.lastIndexOf('.');
            final ext = dot >= 0 ? lower.substring(dot) : '';
            final isJunk = junkExt.contains(ext) ||
                lower.contains('/.thumbnails/') ||
                (ext == '.apk' && lower.contains('/download/'));
            if (isJunk) {
              res[Cat.junk]!.files.add(e);
              res[Cat.junk]!.bytes += size;
            } else if (size >= largeMin) {
              res[Cat.large]!.files.add(e);
              res[Cat.large]!.bytes += size;
            } else if (size >= dupMin) {
              (bySize[size] ??= []).add(_F(path, size));
            }
            if (n % 200 == 0) {
              onProgress(0.1 + 0.5 * (1 - math.exp(-n / 4000)), dir.path);
              await Future<void>.delayed(Duration.zero);
            }
          }
        }
      } catch (_) {}
    }

    // 3. Doublons : même taille, puis même empreinte MD5
    final groups = bySize.values.where((g) => g.length > 1).toList();
    for (var i = 0; i < groups.length && !cancelled; i++) {
      final byHash = <String, List<_F>>{};
      for (final f in groups[i]) {
        try {
          final d = await md5.bind(File(f.path).openRead()).first;
          (byHash[d.toString()] ??= []).add(f);
        } catch (_) {}
      }
      for (final same in byHash.values) {
        if (same.length < 2) continue;
        same.sort((a, b) => a.path.compareTo(b.path));
        for (final extra in same.skip(1)) {
          res[Cat.dup]!.files.add(File(extra.path));
          res[Cat.dup]!.bytes += extra.size;
        }
      }
      onProgress(0.6 + 0.38 * ((i + 1) / groups.length), groups[i].first.path);
    }

    onProgress(1, '');
    return res;
  }

  /// Supprime les fichiers d'une catégorie et renvoie les octets libérés.
  Future<int> delete(Found f) async {
    var freed = 0;
    var i = 0;
    for (final file in f.files) {
      try {
        final s = file.lengthSync();
        file.deleteSync();
        freed += s;
      } catch (_) {}
      if (++i % 100 == 0) await Future<void>.delayed(Duration.zero);
    }
    return freed;
  }

  int _len(File f) {
    try {
      return f.lengthSync();
    } catch (_) {
      return 0;
    }
  }
}

/// État partagé simple (espace disque, total nettoyé, dernière analyse).
class Store {
  static double totalGB = 0;
  static double freeGB = 0;
  static int cleanedBytes = 0;
  static Map<Cat, int> lastFound = {};

  static Future<void> load() async {
    try {
      final p = await SharedPreferences.getInstance();
      cleanedBytes = p.getInt('cleanedBytes') ?? 0;
    } catch (_) {}
    await refreshDisk();
  }

  static Future<void> save() async {
    try {
      final p = await SharedPreferences.getInstance();
      await p.setInt('cleanedBytes', cleanedBytes);
    } catch (_) {}
  }

  static Future<void> refreshDisk() async {
    try {
      final t = await DiskSpacePlus.getTotalDiskSpace;
      final f = await DiskSpacePlus.getFreeDiskSpace;
      totalGB = (t ?? 0) / 1024;
      freeGB = (f ?? 0) / 1024;
    } catch (_) {}
  }
}
