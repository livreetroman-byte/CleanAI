import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:permission_handler/permission_handler.dart';

import 'result_screen.dart';
import 'scanner.dart';
import 'widgets.dart';

enum Phase { asking, denied, scanning, ready, cleaning }

class ScanScreen extends StatefulWidget {
  final Cat? only;
  const ScanScreen({super.key, this.only});
  @override
  State<ScanScreen> createState() => _ScanScreenState();
}

class _ScanScreenState extends State<ScanScreen> {
  final scanner = Scanner();
  Phase phase = Phase.asking;
  double progress = 0;
  String path = '';
  Map<Cat, Found> res = {};
  late Set<Cat> sel;

  static const order = [Cat.junk, Cat.cache, Cat.dup, Cat.large];

  @override
  void initState() {
    super.initState();
    sel = widget.only != null ? {widget.only!} : {Cat.junk, Cat.cache};
    _run();
  }

  @override
  void dispose() {
    scanner.cancelled = true;
    super.dispose();
  }

  Future<void> _run() async {
    setState(() => phase = Phase.asking);
    final ok = await Scanner.ensureAccess();
    if (!mounted) return;
    if (!ok) {
      setState(() => phase = Phase.denied);
      return;
    }
    setState(() {
      phase = Phase.scanning;
      progress = 0;
    });
    final r = await scanner.scan((p, s) {
      if (mounted) setState(() {
            progress = p;
            path = s;
          });
    });
    if (!mounted || scanner.cancelled) return;
    Store.lastFound = {for (final e in r.entries) e.key: e.value.bytes};
    setState(() {
      res = r;
      progress = 1;
      phase = Phase.ready;
    });
  }

  int get total => sel.fold(0, (a, c) => a + (res[c]?.bytes ?? 0));

  Future<void> _clean() async {
    if (sel.contains(Cat.dup) || sel.contains(Cat.large)) {
      final ok = await showDialog<bool>(
        context: context,
        builder: (c) => AlertDialog(
          title: const Text('Suppression définitive'),
          content: const Text('Les doublons et gros fichiers sélectionnés seront supprimés sans passer par une corbeille. Continuer ?'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Annuler')),
            TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('Supprimer')),
          ],
        ),
      );
      if (ok != true) return;
    }
    setState(() => phase = Phase.cleaning);
    final details = <Cat, int>{};
    var freed = 0;
    for (final c in order.where(sel.contains)) {
      final f = await scanner.delete(res[c]!);
      details[c] = f;
      freed += f;
    }
    Store.cleanedBytes += freed;
    await Store.save();
    for (final c in details.keys) {
      Store.lastFound[c] = 0;
    }
    if (!mounted) return;
    Navigator.of(context).pushReplacement(smoothRoute(ResultScreen(freed: freed, details: details)));
  }

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    final display = GoogleFonts.sora(fontWeight: FontWeight.w700, color: p.ink);
    final ready = phase == Phase.ready;

    return Scaffold(
      backgroundColor: p.bg,
      body: GlowBackground(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
            child: Column(children: [
              Row(children: [
                RoundIconButton(icon: Icons.chevron_left_rounded, onTap: () => Navigator.of(context).maybePop()),
                Expanded(child: Center(child: Text('Nettoyage intelligent', style: display.copyWith(fontSize: 17)))),
                const SizedBox(width: 42),
              ]),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(children: [
                    const SizedBox(height: 20),
                    if (phase == Phase.denied) _denied(p, display) else ...[
                      _ring(p, display),
                      const SizedBox(height: 18),
                      Text(
                        switch (phase) {
                          Phase.ready => 'Prêt à nettoyer',
                          Phase.cleaning => 'Suppression en cours',
                          _ => 'Analyse des fichiers',
                        },
                        style: display.copyWith(fontSize: 17),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        ready ? 'Choisis ce que tu veux supprimer' : path,
                        maxLines: 2,
                        textAlign: TextAlign.center,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(color: p.ink2, fontSize: 13),
                      ),
                      const SizedBox(height: 18),
                      _rows(p),
                    ],
                  ]),
                ),
              ),
              if (phase != Phase.denied && phase != Phase.asking) ...[
                if (ready || phase == Phase.cleaning)
                  GradientButton(
                    label: total > 0 ? 'Nettoyer ${fmtBytes(total)}' : 'Rien de sélectionné',
                    busy: phase == Phase.cleaning,
                    onTap: total > 0 ? _clean : null,
                  ),
                const SizedBox(height: 10),
                if (phase != Phase.cleaning) SoftButton(label: 'Annuler', onTap: () => Navigator.of(context).maybePop()),
              ],
            ]),
          ),
        ),
      ),
    );
  }

  Widget _ring(Pal p, TextStyle display) {
    return SizedBox(
      width: 250,
      height: 250,
      child: Stack(alignment: Alignment.center, children: [
        TweenAnimationBuilder<double>(
          tween: Tween(end: progress),
          duration: const Duration(milliseconds: 250),
          builder: (_, v, __) => CustomPaint(
            size: const Size(250, 250),
            painter: RingPainter(v, p.blue.withOpacity(.16)),
          ),
        ),
        Container(
          width: 178,
          height: 178,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: p.surface,
            border: Border.all(color: p.line),
            boxShadow: [BoxShadow(color: p.blue.withOpacity(.2), blurRadius: 30, spreadRadius: -10)],
          ),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Row(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.end, children: [
              Text('${(progress * 100).round()}', style: display.copyWith(fontSize: 52, letterSpacing: -2)),
              Padding(padding: const EdgeInsets.only(bottom: 8, left: 2), child: Text('%', style: display.copyWith(fontSize: 20))),
            ]),
            Text(phase == Phase.asking ? 'Autorisation…' : (phase == Phase.scanning ? 'Analyse…' : 'Terminé'), style: TextStyle(color: p.ink2, fontSize: 14)),
          ]),
        ),
      ]),
    );
  }

  Widget _rows(Pal p) {
    return Container(
      padding: const EdgeInsets.all(6),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: p.line),
      ),
      child: Column(children: [
        for (final c in order)
          InkWell(
            borderRadius: BorderRadius.circular(18),
            onTap: phase == Phase.ready
                ? () => setState(() => sel.contains(c) ? sel.remove(c) : sel.add(c))
                : null,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 11),
              child: Row(children: [
                Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(color: Color.alphaBlend(p.forCat(c).withOpacity(.2), p.surface), borderRadius: BorderRadius.circular(12)),
                  child: Icon(c.icon, size: 20, color: p.forCat(c)),
                ),
                const SizedBox(width: 12),
                Expanded(child: Text(c.label, style: TextStyle(fontWeight: FontWeight.w600, fontSize: 15, color: p.ink))),
                Text(res[c] == null ? '—' : fmtBytes(res[c]!.bytes), style: TextStyle(color: p.ink2, fontSize: 14)),
                const SizedBox(width: 12),
                AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  width: 26,
                  height: 26,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: sel.contains(c) ? p.blue : Colors.transparent,
                    border: Border.all(color: sel.contains(c) ? p.blue : p.ink2.withOpacity(.35), width: 2),
                    boxShadow: sel.contains(c) ? [BoxShadow(color: p.blue.withOpacity(.5), blurRadius: 12)] : null,
                  ),
                  child: sel.contains(c) ? const Icon(Icons.check_rounded, size: 16, color: Colors.white) : null,
                ),
              ]),
            ),
          ),
      ]),
    );
  }

  Widget _denied(Pal p, TextStyle display) {
    return Padding(
      padding: const EdgeInsets.only(top: 40),
      child: Column(children: [
        Icon(Icons.lock_outline_rounded, size: 56, color: p.blue),
        const SizedBox(height: 16),
        Text('Accès aux fichiers requis', style: display.copyWith(fontSize: 18)),
        const SizedBox(height: 8),
        Text(
          'Pour analyser ton stockage, Clean AI a besoin de l’accès à tous les fichiers. Rien n’est envoyé hors de ton téléphone.',
          textAlign: TextAlign.center,
          style: TextStyle(color: p.ink2, height: 1.4),
        ),
        const SizedBox(height: 24),
        GradientButton(label: 'Autoriser', onTap: _run),
        const SizedBox(height: 10),
        SoftButton(label: 'Ouvrir les réglages', onTap: openAppSettings),
      ]),
    );
  }
}
